﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Author : Joshua McCormick
//Creation Date : 31/05/2019
//Version : 1.0
namespace Assessment6
{
    public partial class Calc : Form
    {
        // public variables for the calculations
        public double firstNum=0.0;
        public double secondNum = 0.0;
        public double result = 0.0;
        public bool equalPress = false;
        public bool addPress = false;
        public bool minusPress = false;
        public bool multiPress = false;
        public bool divPress = false;
        public Calc()
        {
            InitializeComponent();
        }
        //this button adds a "1" to the display
        private void btnOne_Click(object sender, EventArgs e)
        {
            if (equalPress)
            {
                clear();
                equalPress = false;
            }
            tbDisplay.Text += 1;
        }
        //this button adds a "2" to the display
        private void btnTwo_Click(object sender, EventArgs e)
        {
            if (equalPress)
            {
                clear();
                equalPress = false;
            }
            tbDisplay.Text += 2;
        }
        //this button adds a "3" to the display
        private void btnThree_Click(object sender, EventArgs e)
        {
            if (equalPress)
            {
                clear();
                equalPress = false;
            }
            tbDisplay.Text += 3;
        }
        //this button adds a "4" to the display
        private void btnFour_Click(object sender, EventArgs e)
        {
            if (equalPress)
            {
                clear();
                equalPress = false;
            }
            tbDisplay.Text += 4;
        }
        //this button adds a "5" to the display
        private void btnFive_Click(object sender, EventArgs e)
        {
            if (equalPress)
            {
                clear();
                equalPress = false;
            }
            tbDisplay.Text += 5;
        }
        //this button adds a "6" to the display
        private void btnSix_Click(object sender, EventArgs e)
        {
            if (equalPress)
            {
                clear();
                equalPress = false;
            }
            tbDisplay.Text += 6;
        }
        //this button adds a "7" to the display
        private void btnSeven_Click(object sender, EventArgs e)
        {
            if (equalPress)
            {
                clear();
                equalPress = false;
            }
            tbDisplay.Text += 7;
        }
        //this button adds a "8" to the display
        private void btnEight_Click(object sender, EventArgs e)
        {
            if(equalPress)
            {
                clear();
                equalPress = false;
            }
            tbDisplay.Text += 8;
        }
        //this button adds a "9" to the display
        private void btnNine_Click(object sender, EventArgs e)
        {
            if(equalPress)
            {
                clear();
                equalPress = false;
            }
            tbDisplay.Text += 9;
        }
        //this button adds a "0" to the display
        private void btnZero_Click(object sender, EventArgs e)
        {
            if(equalPress)
            {
                clear();
                equalPress = false;
            }
            tbDisplay.Text += 0;
        }
        //this button adds a "." to the display
        private void btnPoint_Click(object sender, EventArgs e)
        {
            if(!tbDisplay.Text.Contains("."))
            {
                tbDisplay.Text += ".";
            }            
        }
        //clears the display and resets all the public variables
        private void btnClear_Click(object sender, EventArgs e)
        {
            clear();
            result = 0;
            firstNum = 0;
            secondNum = 0;
            equalPress = false; ;
            addPress = false;
            minusPress = false;
            multiPress = false;
            divPress = false;
    }
        //changes a label to display "+" and take the number entered as the first number
        private void btnPlus_Click(object sender, EventArgs e)
        {
            if(tbDisplay.Text != "")
            {
                addPress = true;
                firstNum = Double.Parse(tbDisplay.Text);
                clear();
                labSign.Text = "+";
            }
            
        }
        //changes a label to display "-" and take the number entered as the first number
        private void btnMinus_Click(object sender, EventArgs e)
        {
            if(tbDisplay.Text != "")
            {
                minusPress = true;
                firstNum = Double.Parse(tbDisplay.Text);
                clear();
                labSign.Text = "-";
            }
            else if(tbDisplay.Text == "")
            {
                tbDisplay.Text += "-";
            }
            
        }
        //changes a label to display "/" and take the number entered as the first number
        private void btnDivide_Click(object sender, EventArgs e)
        {
            if(tbDisplay.Text != "")
            {
                divPress = true;
                firstNum = Double.Parse(tbDisplay.Text);
                clear();
                labSign.Text = "/";
            }
            
        }
        //changes a label to display "*" and take the number entered as the first number
        private void btnTimes_Click(object sender, EventArgs e)
        {
            if(tbDisplay.Text != "")
            {
                multiPress = true;
                firstNum = Double.Parse(tbDisplay.Text);
                clear();
                labSign.Text = "*";
            }
            
        }
        //method for clearing textbox
        public void clear()
        {
            tbDisplay.Clear();
        }
        //changes label to "SQ" and calculates the square root of the number entered and records the result
        private void btnSquareRoot_Click(object sender, EventArgs e)
        {
            if(tbDisplay.Text != "")
            {
                firstNum = Double.Parse(tbDisplay.Text);
                labSign.Text = "SQ";
                clear();
                result = BasicMath.Algebraic.SqRoot(firstNum);
            }
            
        }
        //changes label to "QB" and calculates the square root of the number entered and records the result
        private void btnCubeRoot_Click(object sender, EventArgs e)
        {
            if(tbDisplay.Text != "")
            {
                firstNum = Double.Parse(tbDisplay.Text);
                labSign.Text = "QB";
                clear();
                result = BasicMath.Algebraic.QbRoot(firstNum);
            }
            
        }
        //changes label to "INV" and calculates the square root of the number entered and records the result
        private void btnInverse_Click(object sender, EventArgs e)
        {
            if(tbDisplay.Text != "")
            {
                firstNum = Double.Parse(tbDisplay.Text);
                labSign.Text = "INV";
                clear();
                result = BasicMath.Algebraic.Inverse(firstNum);
            }
            
        }
        //changes label to "TAN" and calculates the square root of the number entered and records the result
        private void btnTan_Click(object sender, EventArgs e)
        {
            if(tbDisplay.Text != "")
            {
                if ((Double.Parse(tbDisplay.Text) != 90) && (Double.Parse(tbDisplay.Text) != 270))
                {
                    firstNum = Double.Parse(tbDisplay.Text);
                    labSign.Text = "TAN";
                    clear();
                    result = BasicMath.Trigonometric.Tan(firstNum);
                }
                else
                {
                    tbDisplay.Text = "Invalid";
                    result = 0.0;
                }
            }
            
        }
        //changes label to "COS" and calculates the square root of the number entered and records the result
        private void btnCos_Click(object sender, EventArgs e)
        {
            if(tbDisplay.Text != "")
            {
                firstNum = Double.Parse(tbDisplay.Text);
                labSign.Text = "COS";
                clear();
                result = BasicMath.Trigonometric.Cos(firstNum);
            }
            
        }
        //changes label to "SIN" and calculates the square root of the number entered and records the result
        private void btnSin_Click(object sender, EventArgs e)
        {
            if(tbDisplay.Text != "")
            {
                firstNum = Double.Parse(tbDisplay.Text);
                labSign.Text = "SIN";
                clear();
                result = BasicMath.Trigonometric.Sin(firstNum);
            }
            
        }
        //displays the result and changes the label to "="
        private void btnEqual_Click(object sender, EventArgs e)
        {
            labSign.Text = "=";
            equalPress = true;
            //if the add button is pressed it knows to calculate it here
            if(addPress)
            {
                //also checks if the display has a value
                if(tbDisplay.Text != "")
                {
                    secondNum = Double.Parse(tbDisplay.Text);
                    result = BasicMath.Arithmetic.Add(firstNum, secondNum);
                    addPress = false;
                }
                
            }
            //if it is the subtraction button
            else if(minusPress)
            {
                if(tbDisplay.Text != "")
                {
                    secondNum = Double.Parse(tbDisplay.Text);
                    result = BasicMath.Arithmetic.Sub(firstNum, secondNum);
                    minusPress = false;
                }
                
            }
            //if it is the division button
            else if(divPress)
            {
                if(tbDisplay.Text != "")
                {
                    secondNum = Double.Parse(tbDisplay.Text);
                    result = BasicMath.Arithmetic.Divide(firstNum, secondNum);
                    divPress = false;
                }
                
            }
            //or the multiplication button
            else if(multiPress)
            {
                if(tbDisplay.Text != "")
                {
                    secondNum = Double.Parse(tbDisplay.Text);
                    result = BasicMath.Arithmetic.Multiply(firstNum, secondNum);
                    multiPress = false;
                }
                
            }
            //always displays the result to a string
            tbDisplay.Text = result.ToString();
        }
    }
}
